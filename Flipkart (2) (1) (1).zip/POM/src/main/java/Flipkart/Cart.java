package Flipkart;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import junit.framework.Assert;

public class Cart {
	
	WebDriver driver;
	public Cart(WebDriver driver) {
		this.driver=driver;
	}
	public HomePage ClickFlipkartLogo() {
		// TODO Auto-generated method stub
		return new HomePage();
	}
	@SuppressWarnings("deprecation")
	public void cartprice() {
		String price1=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div[1]/div/div[2]/div/div[1]/div[1]/span[1]")).getText();
		String cost1 = price1.replaceAll("[^0-9]", "");
		int conclusion1=Integer.valueOf(cost1);

		String price2=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div[1]/div/div[3]/div/div[1]/div[1]/span[1]")).getText();
		String cost2 = price2.replaceAll("[^0-9]", "");
		int conclusion2=Integer.valueOf(cost2);

		String price3=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div[1]/div/div[4]/div/div[1]/div[1]/span[1]")).getText();
		String cost3 = price3.replaceAll("[^0-9]", "");
		int conclusion3=Integer.valueOf(cost3);

		String price4=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div[1]/div/div[5]/div/div[1]/div[1]/span[1]")).getText();
		String cost4 = price4.replaceAll("[^0-9]", "");
		int conclusion4=Integer.valueOf(cost4);
		System.out.println("The cost of first prouct is ₹"+conclusion1);
		System.out.println("The cost of second prouct is ₹"+conclusion2);
		System.out.println("The cost of third prouct is ₹"+conclusion3);
		System.out.println("The cost of fourth prouct is ₹"+conclusion4);
		int Sum=conclusion1+conclusion2+conclusion3+conclusion4;
		
		String Summ="₹"+Sum;
		String finalSum=Summ.substring(0,3)+","+Summ.substring(3);
		System.out.println("Subtotal of all products = "+finalSum);
		String price5=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/div[1]/div/div/div/div[4]/div/span/div/div/span")).getText();
		String cost5 = price5.replaceAll("[^0-9]", "");
		int TotalCart=Integer.valueOf(cost5);
		
		System.out.println("Total Value of Cart = "+price5);
		//Assert.assertEquals(finalSum, price5);
		if (Sum==TotalCart) {
			System.out.println("Given condition passed");
		}else {
			System.out.println("Given condition failed");
		}
		driver.quit();
		
	}
}
